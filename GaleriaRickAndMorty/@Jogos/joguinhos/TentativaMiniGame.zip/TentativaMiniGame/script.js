const fetchApi = (value) => {
    const result = fetch(`https://rickandmortyapi.com/api/character/${value}`)
        .then((res) => res.json())
        .then((data) => {
            console.log(data);
            return data;
        });

    return result;
}

const keys = ['name', 'status', 'species', 'gender', 'origin', 'episode'];
const newKeys = {
    name: 'Nome',
    status: 'Status',
    species: 'Espécie',
    gender: 'Gênero',
    origin: 'Planeta de origem',
    episode: 'Episódios',
}

const revealSteps = [30, 60, 90, 120, 150, 180, 210];
let revealStep = 0;
let correctAnswer = "";

async function loadCharacter() {
    const response = await fetch("https://rickandmortyapi.com/api/character");
    const data = await response.json();

    const characters = data.results;
    const randomIndex = Math.floor(Math.random() * characters.length);
    const selectedCharacter = characters[randomIndex];

    document.getElementById("character-img").src = selectedCharacter.image;
    correctAnswer = selectedCharacter.name.toLowerCase();

    // Resetar estado do jogo
    document.getElementById("image-container").style.height = revealSteps[0] + "px";
    document.getElementById("feedback").textContent = "";
    document.getElementById("guess").value = "";
    document.getElementById("success-overlay").style.display = "none";
    document.getElementById("win-message").style.display = "none";
    document.getElementById("play-again-btn").style.display = "none";
    revealStep = 0;
}

function checkGuess() {
    const userGuess = document.getElementById("guess").value.toLowerCase().trim();
    const feedback = document.getElementById("feedback");

    if (!userGuess) {
        feedback.textContent = "Digite um nome antes de chutar!";
        return;
    }

    if (userGuess === correctAnswer) {
        feedback.textContent = "";
        document.getElementById("success-overlay").style.display = "block";
        document.getElementById("win-message").style.display = "block";
        document.getElementById("play-again-btn").style.display = "inline-block";
    } else {
        feedback.innerHTML = `❌ Você chutou: "${userGuess}". Tente novamente!`;

        if (revealStep < revealSteps.length - 1) {
            revealStep++;
            document.getElementById("image-container").style.height = revealSteps[revealStep] + "px";
        }
    }
}

loadCharacter();